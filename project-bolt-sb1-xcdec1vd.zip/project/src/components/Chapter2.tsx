import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Gamepad2, Delete } from 'lucide-react';

const TARGET_WORD = 'ANMOL';

const KEYBOARD_ROWS = [
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
  ['Z', 'X', 'C', 'V', 'B', 'N', 'M'],
];

type LetterState = 'correct' | 'present' | 'absent' | 'empty';

interface GuessRow {
  letters: string[];
  states: LetterState[];
  revealed: boolean;
}

interface Chapter2Props {
  onComplete: () => void;
}

export function Chapter2({ onComplete }: Chapter2Props) {
  const [guesses, setGuesses] = useState<GuessRow[]>(() =>
    Array.from({ length: 6 }, () => ({
      letters: Array(5).fill(''),
      states: Array(5).fill('empty' as LetterState),
      revealed: false,
    }))
  );
  const [currentRow, setCurrentRow] = useState(0);
  const [currentCol, setCurrentCol] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [shakeRow, setShakeRow] = useState<number | null>(null);
  const [usedKeys, setUsedKeys] = useState<Record<string, LetterState>>({});
  const [showIntro, setShowIntro] = useState(true);
  const [hint, setHint] = useState<string | null>(null);
  const [giveUpMsg, setGiveUpMsg] = useState<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => setShowIntro(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const evaluateGuess = useCallback((guess: string[]): LetterState[] => {
    const states: LetterState[] = Array(5).fill('absent');
    const targetCopy = TARGET_WORD.split('');
    const guessCopy = [...guess];

    for (let i = 0; i < 5; i++) {
      if (guessCopy[i] === targetCopy[i]) {
        states[i] = 'correct';
        targetCopy[i] = '#';
        guessCopy[i] = '*';
      }
    }

    for (let i = 0; i < 5; i++) {
      if (guessCopy[i] !== '*') {
        const idx = targetCopy.indexOf(guessCopy[i]);
        if (idx !== -1) {
          states[i] = 'present';
          targetCopy[idx] = '#';
        }
      }
    }

    return states;
  }, []);

  const updateUsedKeys = useCallback((guess: string[], states: LetterState[]) => {
    setUsedKeys(prev => {
      const next = { ...prev };
      for (let i = 0; i < 5; i++) {
        const letter = guess[i];
        const state = states[i];
        const current = next[letter];
        if (state === 'correct') {
          next[letter] = 'correct';
        } else if (state === 'present' && current !== 'correct') {
          next[letter] = 'present';
        } else if (!current) {
          next[letter] = 'absent';
        }
      }
      return next;
    });
  }, []);

  const triggerGameOver = useCallback((didWin: boolean) => {
    setGameOver(true);
    if (didWin) {
      setWon(true);
      setTimeout(onComplete, 2500);
    } else {
      setGiveUpMsg("WOW, OK FINE");
      setTimeout(() => {
        setGiveUpMsg(null);
        setTimeout(onComplete, 1200);
      }, 2500);
    }
  }, [onComplete]);

  const submitGuess = useCallback(() => {
    if (gameOver) return;
    if (currentCol < 5) {
      setShakeRow(currentRow);
      setTimeout(() => setShakeRow(null), 400);
      return;
    }

    const guess = guesses[currentRow].letters;
    const states = evaluateGuess(guess);
    const isCorrect = guess.join('') === TARGET_WORD;

    setGuesses(prev => {
      const next = [...prev];
      next[currentRow] = { letters: guess, states, revealed: true };
      return next;
    });

    updateUsedKeys(guess, states);

    if (isCorrect) {
      triggerGameOver(true);
      return;
    }

    const nextRow = currentRow + 1;

    // Hint after 3rd wrong guess
    if (nextRow === 3) {
      setTimeout(() => setHint("He's got great abs."), 600);
    }

    // Give up after 6th wrong guess
    if (nextRow >= 6) {
      triggerGameOver(false);
      return;
    }

    // Stronger hint after 5th wrong guess
    if (nextRow === 5) {
      setTimeout(() => setHint("Bruh, It's Adi."), 600);
    }

    setCurrentRow(nextRow);
    setCurrentCol(0);
  }, [currentCol, currentRow, gameOver, guesses, evaluateGuess, updateUsedKeys, triggerGameOver]);

  const handleKeyPress = useCallback((key: string) => {
    if (gameOver) return;

    if (key === 'ENTER') {
      submitGuess();
      return;
    }

    if (key === 'BACK') {
      if (currentCol > 0) {
        const newCol = currentCol - 1;
        setGuesses(prev => {
          const next = [...prev];
          next[currentRow] = {
            ...next[currentRow],
            letters: next[currentRow].letters.map((l, i) => (i === newCol ? '' : l)),
          };
          return next;
        });
        setCurrentCol(newCol);
      }
      return;
    }

    if (currentCol < 5) {
      setGuesses(prev => {
        const next = [...prev];
        const letters = [...next[currentRow].letters];
        letters[currentCol] = key;
        next[currentRow] = { ...next[currentRow], letters };
        return next;
      });
      setCurrentCol(prev => Math.min(prev + 1, 5));
    }
  }, [currentCol, currentRow, gameOver, submitGuess]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter') handleKeyPress('ENTER');
      else if (e.key === 'Backspace') handleKeyPress('BACK');
      else if (/^[a-zA-Z]$/.test(e.key)) handleKeyPress(e.key.toUpperCase());
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyPress]);

  const getCellStyle = (state: LetterState, revealed: boolean) => {
    if (!revealed || state === 'empty') return 'border-white/10 bg-white/[0.02]';
    if (state === 'correct') return 'border-green-500/50 bg-green-600/30';
    if (state === 'present') return 'border-yellow-500/50 bg-yellow-500/25';
    return 'border-white/5 bg-slate-700/40';
  };

  const getKeyStyle = (key: string) => {
    const state = usedKeys[key];
    if (state === 'correct') return 'bg-green-600/40 text-white border-green-500/40';
    if (state === 'present') return 'bg-yellow-500/25 text-white border-yellow-500/30';
    if (state === 'absent') return 'bg-slate-700/40 text-white/30 border-slate-600/30';
    return 'bg-white/10 text-white/80 border-white/10 hover:bg-white/15';
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="min-h-screen flex flex-col items-center justify-center px-4 py-8 relative"
    >
      {/* Intro modal */}
      <AnimatePresence>
        {showIntro && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, y: -30 }}
            className="fixed inset-0 z-50 flex items-center justify-center px-4"
          >
            <div className="glass-strong rounded-2xl p-8 md:p-12 neon-border max-w-md text-center">
              <Gamepad2 className="w-8 h-8 text-neon-blue mx-auto mb-4" />
              <h3 className="text-xl md:text-2xl font-semibold text-white mb-3">
                The Gatekeeper
              </h3>
              <p className="text-white/50 text-sm leading-relaxed">
                To unlock your stats, you must solve today's mystery.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hint popup */}
      <AnimatePresence>
        {hint && !gameOver && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 200 }}
            className="fixed top-1/3 left-1/2 -translate-x-1/2 z-50"
          >
            <div className="glass-strong rounded-2xl px-8 py-5 neon-border text-center">
              <p className="text-neon-blue text-sm md:text-base font-medium text-glow">
                {hint}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chapter label */}
      <div className="mb-8 text-center">
        <p className="text-[10px] uppercase tracking-[0.4em] text-neon-blue/40 font-medium">
          Chapter II
        </p>
        <h2 className="text-xl md:text-3xl font-semibold text-white mt-1">
          Who's the thief?
        </h2>
      </div>

      {/* Grid */}
      <div className="space-y-2 mb-8">
        {guesses.map((row, rowIdx) => (
          <motion.div
            key={rowIdx}
            className="flex gap-2"
            animate={shakeRow === rowIdx ? { x: [-6, 6, -6, 6, 0] } : {}}
            transition={{ duration: 0.3 }}
          >
            {row.letters.map((letter, colIdx) => (
              <motion.div
                key={colIdx}
                className={`w-12 h-12 md:w-14 md:h-14 rounded-lg border-2 flex items-center justify-center text-lg md:text-xl font-semibold transition-all duration-500 relative ${getCellStyle(row.states[colIdx], row.revealed)}`}
                animate={
                  row.revealed && row.states[colIdx] === 'correct'
                    ? { scale: [1, 1.1, 1] }
                    : {}
                }
                transition={{ duration: 0.3, delay: colIdx * 0.1 }}
              >
                <span className="text-white">
                  {letter}
                </span>
                {row.revealed && row.states[colIdx] === 'correct' && (
                  <div className="absolute inset-0 rounded-lg bg-green-500/10 animate-pulse-glow" />
                )}
              </motion.div>
            ))}
          </motion.div>
        ))}
      </div>

      {/* Keyboard */}
      <div className="space-y-2 max-w-lg w-full">
        {KEYBOARD_ROWS.map((row, rowIdx) => (
          <div key={rowIdx} className="flex justify-center gap-1 md:gap-1.5">
            {rowIdx === 2 && (
              <motion.button
                onClick={() => handleKeyPress('ENTER')}
                className="px-3 md:px-4 h-11 md:h-12 rounded-lg bg-electric-500/20 border border-electric-400/20 text-white text-xs font-medium tracking-wider hover:bg-electric-500/30 transition-all"
                whileTap={{ scale: 0.95 }}
              >
                ENTER
              </motion.button>
            )}
            {row.map(key => (
              <motion.button
                key={key}
                onClick={() => handleKeyPress(key)}
                className={`w-8 md:w-10 h-11 md:h-12 rounded-lg border text-xs md:text-sm font-medium transition-all duration-200 ${getKeyStyle(key)}`}
                whileTap={{ scale: 0.9 }}
              >
                {key}
              </motion.button>
            ))}
            {rowIdx === 2 && (
              <motion.button
                onClick={() => handleKeyPress('BACK')}
                className="px-2 md:px-3 h-11 md:h-12 rounded-lg bg-white/5 border border-white/10 text-white/60 hover:bg-white/10 transition-all"
                whileTap={{ scale: 0.95 }}
              >
                <Delete className="w-4 h-4" />
              </motion.button>
            )}
          </div>
        ))}
      </div>

      {/* Game over overlay */}
      <AnimatePresence>
        {gameOver && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-40 bg-slate-950/80 flex items-center justify-center px-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 200 }}
              className="text-center"
            >
              {won ? (
                <p className="text-3xl md:text-5xl font-bold text-glow-lg text-white">
                  Yeah thats right! He stole your heart!
                </p>
              ) : (
                <div className="space-y-4">
                  <p className="text-3xl md:text-5xl font-bold text-glow-lg text-white">
                    {giveUpMsg || "WOW BRUH, OK FINE"}
                  </p>
                  <p className="text-lg md:text-2xl text-neon-blue font-medium">
                    The word was: {TARGET_WORD}
                  </p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
