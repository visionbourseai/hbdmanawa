import { useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { useMouseSpotlight, useSparkleBurst, SparkleParticle } from '../hooks/useMouseSpotlight';

export function SparkleEffect() {
  const { x, y } = useMouseSpotlight();
  const { bursts, createBurst } = useSparkleBurst();
  const lastBurstRef = useRef(0);
  const lastTrailRef = useRef(0);

  // Trail sparkles on mouse move
  useEffect(() => {
    const now = Date.now();
    if (x < 0 || y < 0) return;
    if (now - lastTrailRef.current > 50) {
      lastTrailRef.current = now;
      createBurst(x, y, 4);
    }
  }, [x, y, createBurst]);

  // Burst on click/touch
  const handleInteraction = useCallback((clientX: number, clientY: number) => {
    const now = Date.now();
    if (now - lastBurstRef.current > 100) {
      lastBurstRef.current = now;
      createBurst(clientX, clientY, 18);
    }
  }, [createBurst]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => handleInteraction(e.clientX, e.clientY);
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        handleInteraction(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    window.addEventListener('click', handleClick);
    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    return () => {
      window.removeEventListener('click', handleClick);
      window.removeEventListener('touchstart', handleTouchStart);
    };
  }, [handleInteraction]);

  return (
    <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden">
      {/* Cursor glow */}
      <div
        className="absolute w-48 h-48 rounded-full transition-transform duration-75"
        style={{
          left: x - 96,
          top: y - 96,
          background: 'radial-gradient(circle, rgba(96,165,250,0.12) 0%, rgba(96,165,250,0.04) 40%, transparent 70%)',
        }}
      />

      {/* Sparkle bursts */}
      {bursts.map(burst => (
        <div key={burst.id} className="absolute" style={{ left: 0, top: 0 }}>
          {burst.particles.map(particle => (
            <SparkleParticleComponent
              key={particle.id}
              particle={particle}
              originX={burst.x}
              originY={burst.y}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

function SparkleParticleComponent({
  particle,
  originX,
  originY,
}: {
  particle: SparkleParticle;
  originX: number;
  originY: number;
}) {
  const dx = Math.cos(particle.angle) * particle.speed;
  const dy = Math.sin(particle.angle) * particle.speed;

  return (
    <motion.div
      className="absolute rounded-full"
      style={{
        left: originX,
        top: originY,
        width: particle.size,
        height: particle.size,
        background: particle.color,
        boxShadow: `0 0 ${particle.size * 3}px ${particle.color}, 0 0 ${particle.size * 6}px ${particle.color.replace('1)', '0.3)')}`,
      }}
      initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
      animate={{
        x: dx,
        y: dy,
        opacity: [1, 1, 0],
        scale: [0, 1.2, 0],
      }}
      transition={{
        duration: particle.life,
        delay: particle.delay,
        ease: 'easeOut',
      }}
    />
  );
}
