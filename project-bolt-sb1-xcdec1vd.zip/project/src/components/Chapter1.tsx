import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Heart, MapPin, Plane, Music, Camera, Coffee, Star, MessageCircle } from 'lucide-react';

const FRIEND_NAME = 'Bestie';
const AGE = 22;

const scrapbookEntries = [
  {
    icon: MapPin,
    title: 'Our First CIA',
    caption: `So glad you thought you could get notes from me lol.`,
    span: 'col-span-2 row-span-2',
    image: 'https://lh3.googleusercontent.com/d/1mEhQJLUDoBRadV-VqdMfaWzJdPDcPKvC',
  },
  {
    icon: Coffee,
    title: 'The Auction',
    caption: 'When you auctioned me coz kamran and yahya disowned me.',
    span: 'col-span-1 row-span-1',
    image: 'https://lh3.googleusercontent.com/d/11Gwch-Gajq_X-dTc8uMDfeNuoEnbLhIQ',
  },
  {
    icon: Music,
    title: 'Sleepy Baby',
    caption: "hehe.",
    span: 'col-span-1 row-span-1',
    image: 'https://lh3.googleusercontent.com/d/1AJI20XiyyYKT3YhJUBzxz3LTvMKqOseW',
  },
  {
    icon: Camera,
    title: 'The Us Pic',
    caption: "We rock.",
    span: 'col-span-1 row-span-2',
    image: 'https://lh3.googleusercontent.com/d/1Pwmv9YQSAzIcqNq634l_RVBBLsUbsUAW',
  },
  {
    icon: Plane,
    title: 'The Diva that you are',
    caption: "Forever.",
    span: 'col-span-1 row-span-1',
    image: 'https://lh3.googleusercontent.com/d/15qinVoKAquY3TOY4WlJflHIxXd7mKEtG',
  },
  {
    icon: Star,
    title: 'Cutiee Pie',
    caption: "22 years young now. Crazyyyy.",
    span: 'col-span-1 row-span-1',
    image: 'https://lh3.googleusercontent.com/d/1t4y9bZ_mT9_qV9GEOpT3dmoigkKHmlGd',
  },

  {
    icon: Heart,
    title: 'Our Ethnic Day Thing',
    caption: `Keep enlightening us with your wisdom, Philosopher Manawa.`,
    span: 'col-span-2 row-span-2',
    image: 'https://lh3.googleusercontent.com/d/1z-lFdwJLLB_ANovGXw9r9BYZZUU6WD-e',
  },
];

interface Chapter1Props {
  onComplete: () => void;
}

export function Chapter1({ onComplete }: Chapter1Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const bottomInView = useInView(bottomRef, { once: true, margin: '-100px' });

  return (
    <div ref={scrollRef} className="min-h-screen relative">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="sticky top-0 z-20 glass-strong border-b border-white/5"
      >
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-neon-blue/50 font-medium">
              Chapter I
            </p>
            <h2 className="text-2xl md:text-4xl font-semibold text-white mt-1">
              The Legend of Us
            </h2>
          </div>
          <motion.div
            className="px-4 py-2 rounded-lg bg-electric-500/10 border border-electric-400/20"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, type: 'spring' }}
          >
            <span className="text-neon-blue text-sm font-medium">Level {AGE}</span>
          </motion.div>
        </div>
      </motion.div>

      {/* Bento Grid */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[180px] md:auto-rows-[220px]">
          {scrapbookEntries.map((entry, i) => {
            const Icon = entry.icon;
            return (
              <ScrapbookCard key={i} entry={entry} index={i} Icon={Icon} />
            );
          })}
        </div>
      </div>

      {/* Bottom trigger for next chapter */}
      <div ref={bottomRef} className="h-32 flex items-center justify-center">
        <motion.button
          onClick={onComplete}
          initial={{ opacity: 0, y: 20 }}
          animate={bottomInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="px-8 py-4 rounded-2xl glass neon-border text-white/80 text-sm font-medium tracking-wide hover:text-white hover:border-neon-blue/40 transition-all duration-500 group"
        >
          <span className="flex items-center gap-3">
            Ready to Solve a Mystery?
            <motion.span
              animate={{ y: [0, 4, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              ↓
            </motion.span>
          </span>
        </motion.button>
      </div>
    </div>
  );
}

function ScrapbookCard({ entry, index, Icon }: {
  entry: typeof scrapbookEntries[number];
  index: number;
  Icon: typeof scrapbookEntries[number]['icon'];
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <motion.div
      ref={ref}
      className={`${entry.span} relative rounded-2xl overflow-hidden group cursor-default`}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.6, delay: index * 0.08, ease: 'easeOut' }}
    >
      {/* Image */}
      <div className="absolute inset-0">
        <img
          src={entry.image}
          alt={entry.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-slate-950/20" />
      </div>

      {/* Glass overlay */}
      <div className="absolute inset-0 glass opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      {/* Content */}
      <div className="relative h-full flex flex-col justify-end p-5 md:p-6">
        <div className="flex items-center gap-2 mb-2">
          <Icon className="w-4 h-4 text-neon-blue" />
          <span className="text-[10px] uppercase tracking-[0.25em] text-neon-blue/70 font-medium">
            {entry.title}
          </span>
        </div>
        <p className="text-white/70 text-xs md:text-sm leading-relaxed line-clamp-3 group-hover:line-clamp-none transition-all duration-300">
          {entry.caption}
        </p>
      </div>

    </motion.div>
  );
}
