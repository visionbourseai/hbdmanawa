import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Heart, MapPin, Plane, Music, Camera, Coffee, Star, MessageCircle } from 'lucide-react';

const FRIEND_NAME = 'Bestie';
const AGE = 22;

const scrapbookEntries = [
  {
    icon: MapPin,
    title: 'The Distance',
    caption: `Thousands of miles between us, but somehow it never felt that far. From late-night calls across time zones to sending each other screenshots of our lives — we built a bridge no map could measure.`,
    span: 'col-span-2 row-span-2',
    image: '/images/scrapbook-1.jpg',
  },
  {
    icon: Coffee,
    title: 'Morning Rituals',
    caption: 'Remember when we started the tradition of sending each other our morning coffee? Yours always looked way more aesthetic.',
    span: 'col-span-1 row-span-1',
    image: '/images/scrapbook-2.jpg',
  },
  {
    icon: Music,
    title: 'Our Playlist',
    caption: "That playlist we made? It's basically a time capsule. Every song takes me right back to a specific moment with you.",
    span: 'col-span-1 row-span-1',
    image: '/images/scrapbook-3.jpg',
  },
  {
    icon: Camera,
    title: 'Photo Dumps',
    caption: "From blurry selfies to aesthetic photo dumps — we've documented every chapter of our friendship. No filter needed when the memories are this good.",
    span: 'col-span-1 row-span-2',
    image: '/images/scrapbook-4.jpg',
  },
  {
    icon: Plane,
    title: 'The Reunions',
    caption: "Every airport pickup felt like a movie scene. The running hug, the tears, the 'I can't believe you're actually here' moment. Worth every single mile of separation.",
    span: 'col-span-1 row-span-1',
    image: '/images/scrapbook-5.jpg',
  },
  {
    icon: MessageCircle,
    title: '2 AM Conversations',
    caption: "Some of our best talks happened when the rest of the world was asleep. Processing life together, one voice note at a time.",
    span: 'col-span-1 row-span-1',
    image: '/images/scrapbook-6.jpg',
  },
  {
    icon: Star,
    title: 'Big Dreams',
    caption: "We've always dreamed big together. And look at us now — still dreaming, still believing, still cheering each other on from wherever we are.",
    span: 'col-span-2 row-span-1',
    image: '/images/scrapbook-7.jpg',
  },
  {
    icon: Heart,
    title: 'The Constant',
    caption: `Through every season, every change, every twist — you've been my constant. Distance tested us, but it never won. And it never will. Happy Birthday, ${FRIEND_NAME}. You are so deeply loved.`,
    span: 'col-span-2 row-span-2',
    image: '/images/scrapbook-8.jpg',
  },
];

interface Chapter1Props {
  onComplete: () => void;
}

export function Chapter1({ onComplete }: Chapter1Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const bottomInView = useInView(bottomRef, { once: true, margin: '-100px' });

  return (
    <div ref={scrollRef} className="min-h-screen relative">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="sticky top-0 z-20 glass-strong border-b border-white/5"
      >
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-neon-blue/50 font-medium">
              Chapter I
            </p>
            <h2 className="text-2xl md:text-4xl font-semibold text-white mt-1">
              The Legend of Us
            </h2>
          </div>
          <motion.div
            className="px-4 py-2 rounded-lg bg-electric-500/10 border border-electric-400/20"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, type: 'spring' }}
          >
            <span className="text-neon-blue text-sm font-medium">Level {AGE}</span>
          </motion.div>
        </div>
      </motion.div>

      {/* Bento Grid */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[180px] md:auto-rows-[220px]">
          {scrapbookEntries.map((entry, i) => {
            const Icon = entry.icon;
            return (
              <ScrapbookCard key={i} entry={entry} index={i} Icon={Icon} />
            );
          })}
        </div>
      </div>

      {/* Bottom trigger for next chapter */}
      <div ref={bottomRef} className="h-32 flex items-center justify-center">
        <motion.button
          onClick={onComplete}
          initial={{ opacity: 0, y: 20 }}
          animate={bottomInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="px-8 py-4 rounded-2xl glass neon-border text-white/80 text-sm font-medium tracking-wide hover:text-white hover:border-neon-blue/40 transition-all duration-500 group"
        >
          <span className="flex items-center gap-3">
            Ready for the next challenge?
            <motion.span
              animate={{ y: [0, 4, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              ↓
            </motion.span>
          </span>
        </motion.button>
      </div>
    </div>
  );
}

function ScrapbookCard({ entry, index, Icon }: {
  entry: typeof scrapbookEntries[number];
  index: number;
  Icon: typeof scrapbookEntries[number]['icon'];
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <motion.div
      ref={ref}
      className={`${entry.span} relative rounded-2xl overflow-hidden group cursor-default`}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.6, delay: index * 0.08, ease: 'easeOut' }}
    >
      {/* Image */}
      <div className="absolute inset-0">
        <img
          src={entry.image}
          alt={entry.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-slate-950/20" />
      </div>

      {/* Glass overlay */}
      <div className="absolute inset-0 glass opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      {/* Content */}
      <div className="relative h-full flex flex-col justify-end p-5 md:p-6">
        <div className="flex items-center gap-2 mb-2">
          <Icon className="w-4 h-4 text-neon-blue" />
          <span className="text-[10px] uppercase tracking-[0.25em] text-neon-blue/70 font-medium">
            {entry.title}
          </span>
        </div>
        <p className="text-white/70 text-xs md:text-sm leading-relaxed line-clamp-3 group-hover:line-clamp-none transition-all duration-300">
          {entry.caption}
        </p>
      </div>

      {/* Shine effect on hover */}
      <div className="absolute inset-0 card-shine opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
    </motion.div>
  );
}
