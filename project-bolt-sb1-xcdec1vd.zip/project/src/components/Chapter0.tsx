import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { Lock } from 'lucide-react';

const FRIEND_NAME = 'Bestie';
const CORRECT_AGE = 22;

const WRONG_AGE_MESSAGES = [
  'Too old! Try again, grandma.',
  "We wish! But nope, try again.",
  "Nice try, but you're not fooling anyone!",
  'Did you forget already? Try again!',
  "Close, but no cigar. Try again!",
  "Hmm, that's not quite right...",
  "Are you sure about that? Think harder!",
];

interface Chapter0Props {
  onComplete: () => void;
}

export function Chapter0({ onComplete }: Chapter0Props) {
  const [phase, setPhase] = useState<'typewriter' | 'reveal' | 'confetti' | 'gate'>('typewriter');
  const [typewriterText, setTypewriterText] = useState('');
  const [ageInput, setAgeInput] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isShaking, setIsShaking] = useState(false);
  const [isZooming, setIsZooming] = useState(false);

  const fullText = `hey ${FRIEND_NAME}, wassup, whatchu doin...`;

  useEffect(() => {
    if (phase !== 'typewriter') return;
    let index = 0;
    const interval = setInterval(() => {
      if (index < fullText.length) {
        setTypewriterText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
        setTimeout(() => setPhase('reveal'), 2000);
      }
    }, 60);
    return () => clearInterval(interval);
  }, [phase, fullText]);

  useEffect(() => {
    if (phase === 'reveal') {
      setTimeout(() => setPhase('confetti'), 800);
    }
  }, [phase]);

  useEffect(() => {
    if (phase === 'confetti') {
      const duration = 2000;
      const end = Date.now() + duration;
      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ['#60a5fa', '#93c5fd', '#3b82f6', '#dbeafe', '#ffffff'],
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ['#60a5fa', '#93c5fd', '#3b82f6', '#dbeafe', '#ffffff'],
        });
        if (Date.now() < end) requestAnimationFrame(frame);
      };
      frame();
      setTimeout(() => setPhase('gate'), 2500);
    }
  }, [phase]);

  const handleAgeSubmit = useCallback(() => {
    const age = parseInt(ageInput);
    if (isNaN(age)) {
      setErrorMessage('Enter a number, silly!');
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      return;
    }
    if (age === CORRECT_AGE) {
      setIsZooming(true);
      setTimeout(onComplete, 1200);
    } else {
      const msg = WRONG_AGE_MESSAGES[Math.floor(Math.random() * WRONG_AGE_MESSAGES.length)];
      setErrorMessage(msg);
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      setAgeInput('');
    }
  }, [ageInput, onComplete]);

  return (
    <motion.div
      className={`fixed inset-0 z-30 flex items-center justify-center gradient-moving ${isZooming ? 'zoom-effect' : ''}`}
      animate={isZooming ? { scale: 8, opacity: 0 } : { scale: 1, opacity: 1 }}
      transition={{ duration: 1.2, ease: 'easeInOut' }}
    >
      <div className="bg-mesh absolute inset-0" />

      <AnimatePresence mode="wait">
        {phase === 'typewriter' && (
          <motion.div
            key="typewriter"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -30 }}
            className="relative z-10 text-center px-6"
          >
            <p className="text-2xl md:text-4xl font-light text-white/80 tracking-wide">
              {typewriterText}
              <span className="animate-pulse text-neon-blue">|</span>
            </p>
          </motion.div>
        )}

        {phase === 'reveal' && (
          <motion.div
            key="reveal"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, type: 'spring', stiffness: 100 }}
            className="relative z-10 text-center px-6"
          >
            <h1 className="text-4xl md:text-7xl font-bold text-glow-lg text-white leading-tight">
              OH WAIT, IT'S YOUR
              <br />
              BIRTHDAY!
            </h1>
            <motion.p
              className="text-2xl md:text-4xl font-semibold text-neon-blue mt-4 text-glow"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              HAPPY BIRTHDAY!
            </motion.p>
          </motion.div>
        )}

        {phase === 'confetti' && (
          <motion.div
            key="confetti"
            initial={{ opacity: 1 }}
            animate={{ opacity: 1 }}
            className="relative z-10 text-center px-6"
          >
            <h1 className="text-4xl md:text-7xl font-bold text-glow-lg text-white">
              HAPPY BIRTHDAY!
            </h1>
          </motion.div>
        )}

        {phase === 'gate' && (
          <motion.div
            key="gate"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="relative z-10 text-center px-6 max-w-lg w-full"
          >
            <motion.div
              className="glass-strong rounded-2xl p-8 md:p-12 neon-border"
              animate={isShaking ? { x: [-10, 10, -10, 10, 0] } : { x: 0 }}
              transition={{ duration: 0.4 }}
            >
              <div className="flex items-center justify-center mb-6">
                <Lock className="w-6 h-6 text-neon-blue mr-3" />
                <span className="text-xs uppercase tracking-[0.3em] text-neon-blue/60 font-medium">
                  Verification Required
                </span>
              </div>

              <p className="text-white/60 text-sm md:text-base mb-8 leading-relaxed">
                But first, prove it's you.
                <br />
                <span className="text-white/90">How old are you turning today?</span>
              </p>

              <div className="flex flex-col items-center gap-4">
                <input
                  type="number"
                  value={ageInput}
                  onChange={e => {
                    setAgeInput(e.target.value);
                    setErrorMessage('');
                  }}
                  onKeyDown={e => e.key === 'Enter' && handleAgeSubmit()}
                  placeholder="Your age"
                  className="w-48 bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-center text-2xl font-light text-white placeholder-white/20 focus:outline-none focus:border-neon-blue/40 focus:ring-2 focus:ring-neon-blue/20 transition-all duration-300"
                  autoFocus
                />

                <AnimatePresence>
                  {errorMessage && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="text-neon-blue text-sm font-medium"
                    >
                      {errorMessage}
                    </motion.p>
                  )}
                </AnimatePresence>

                <motion.button
                  onClick={handleAgeSubmit}
                  className="mt-2 px-8 py-3 rounded-xl bg-electric-500/20 border border-electric-400/30 text-white text-sm font-medium tracking-wide hover:bg-electric-500/30 hover:border-electric-400/50 transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Verify
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
