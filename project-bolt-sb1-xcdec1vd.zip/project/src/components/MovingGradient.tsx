export function MovingGradient() {
  return (
    <div className="fixed inset-0 z-0 gradient-moving">
      <div className="absolute inset-0 bg-mesh" />
      {/* Subtle animated orbs */}
      <div className="absolute top-1/4 -left-1/4 w-1/2 h-1/2 bg-electric-500/[0.03] rounded-full blur-[120px] animate-float" />
      <div className="absolute bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-neon-blue/[0.02] rounded-full blur-[100px] animate-float" style={{ animationDelay: '3s' }} />
      <div className="absolute top-3/4 left-1/3 w-1/3 h-1/3 bg-electric-400/[0.02] rounded-full blur-[80px] animate-float" style={{ animationDelay: '5s' }} />
    </div>
  );
}
