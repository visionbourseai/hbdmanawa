import { useMouseSpotlight } from '../hooks/useMouseSpotlight';

export function Spotlight() {
  const { x, y } = useMouseSpotlight();

  return (
    <div
      className="pointer-events-none fixed inset-0 z-50 transition-opacity duration-100"
      style={{
        background: `radial-gradient(800px circle at ${x}px ${y}px, rgba(59, 130, 246, 0.08), transparent 40%)`,
      }}
    />
  );
}
