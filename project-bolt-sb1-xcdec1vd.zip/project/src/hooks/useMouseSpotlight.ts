import { useState, useEffect, useCallback } from 'react';

export function useMouseSpotlight() {
  const [position, setPosition] = useState({ x: -100, y: -100 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        setPosition({ x: e.touches[0].clientX, y: e.touches[0].clientY });
      }
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('touchmove', handleTouchMove);
    };
  }, []);

  return position;
}

export interface SparkleBurst {
  id: number;
  x: number;
  y: number;
  particles: SparkleParticle[];
  timestamp: number;
}

export interface SparkleParticle {
  id: number;
  angle: number;
  speed: number;
  size: number;
  color: string;
  life: number;
  delay: number;
}

const SPARKLE_COLORS = [
  'rgba(96,165,250,1)',
  'rgba(147,197,253,1)',
  'rgba(59,130,246,1)',
  'rgba(219,234,254,1)',
  'rgba(255,255,255,0.9)',
  'rgba(191,219,254,1)',
];

export function useSparkleBurst() {
  const [bursts, setBursts] = useState<SparkleBurst[]>([]);

  const createBurst = useCallback((x: number, y: number, count: number = 12) => {
    const particles: SparkleParticle[] = Array.from({ length: count }, (_, i) => ({
      id: Date.now() + i + Math.random(),
      angle: (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.8,
      speed: 40 + Math.random() * 80,
      size: 2 + Math.random() * 4,
      color: SPARKLE_COLORS[Math.floor(Math.random() * SPARKLE_COLORS.length)],
      life: 0.6 + Math.random() * 0.8,
      delay: Math.random() * 0.15,
    }));

    const burst: SparkleBurst = {
      id: Date.now() + Math.random(),
      x,
      y,
      particles,
      timestamp: Date.now(),
    };

    setBursts(prev => [...prev.slice(-8), burst]);
  }, []);

  // Cleanup old bursts
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setBursts(prev => prev.filter(b => now - b.timestamp < 2000));
    }, 500);
    return () => clearInterval(interval);
  }, []);

  return { bursts, createBurst };
}
