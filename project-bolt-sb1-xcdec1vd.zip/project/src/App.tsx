import { useState, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Chapter0 } from './components/Chapter0';
import { Chapter1 } from './components/Chapter1';
import { Chapter2 } from './components/Chapter2';
import { Chapter3 } from './components/Chapter3';
import { Spotlight } from './components/Spotlight';
import { SparkleEffect } from './components/SparkleEffect';
import { MovingGradient } from './components/MovingGradient';

type Chapter = 0 | 1 | 2 | 3;

function App() {
  const [chapter, setChapter] = useState<Chapter>(0);

  const goToChapter = useCallback((next: Chapter) => {
    setChapter(next);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      <MovingGradient />
      <Spotlight />
      <SparkleEffect />

      <AnimatePresence mode="wait">
        {chapter === 0 && (
          <motion.div
            key="chapter0"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Chapter0 onComplete={() => goToChapter(1)} />
          </motion.div>
        )}

        {chapter === 1 && (
          <motion.div
            key="chapter1"
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -60 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <Chapter1 onComplete={() => goToChapter(2)} />
          </motion.div>
        )}

        {chapter === 2 && (
          <motion.div
            key="chapter2"
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <Chapter2 onComplete={() => goToChapter(3)} />
          </motion.div>
        )}

        {chapter === 3 && (
          <motion.div
            key="chapter3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: 'easeOut' }}
          >
            <Chapter3 />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
