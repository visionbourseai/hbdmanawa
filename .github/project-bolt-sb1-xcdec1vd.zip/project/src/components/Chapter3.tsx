import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import { useMouseSpotlight } from '../hooks/useMouseSpotlight';
import { Award, Heart, MapPin, Sparkles, Trophy } from 'lucide-react';

const FRIEND_NAME = 'Bestie';
const AGE = 22;

const STATS = [
  { label: 'GPA', value: 4, max: 4, icon: Award },
  { label: 'Awesomeness', value: 1000, max: 10, icon: Sparkles },
  { label: 'Beauty', value: 10000, max: 10, icon: Heart },
  { label: 'Bestie', value: 'infinity', max: 10, icon: Heart },
  { label: 'Survival Skills', value: 4, max: 10, icon: MapPin },
  { label: 'Spatial Awareness', value: 2, max: 10, icon: Trophy },
];

export function Chapter3() {
  const [confettiDone, setConfettiDone] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const mouse = useMouseSpotlight();

  useState(() => {
    const duration = 4000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 45 + Math.random() * 90,
        spread: 60 + Math.random() * 40,
        origin: { x: Math.random(), y: Math.random() * 0.5 },
        colors: ['#60a5fa', '#93c5fd', '#3b82f6', '#dbeafe', '#ffffff', '#bfdbfe'],
        shapes: ['circle', 'square'],
      });
      if (Date.now() < end) requestAnimationFrame(frame);
    };

    frame();

    const stars = setInterval(() => {
      confetti({
        particleCount: 2,
        angle: 270,
        spread: 180,
        origin: { x: 0.5, y: -0.1 },
        colors: ['#60a5fa', '#ffffff', '#93c5fd'],
        shapes: ['circle'],
        gravity: 0.3,
        scalar: 0.8,
      });
    }, 200);

    setTimeout(() => {
      clearInterval(stars);
      setConfettiDone(true);
    }, 4500);

    return () => clearInterval(stars);
  });

  const handleCardMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;

    const rotateX = (y - 0.5) * -20;
    const rotateY = (x - 0.5) * 20;

    cardRef.current.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  };

  const handleCardMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
  };

  const shimmerX = mouse.x - (cardRef.current?.getBoundingClientRect().left ?? 0);
  const shimmerY = mouse.y - (cardRef.current?.getBoundingClientRect().top ?? 0);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen flex flex-col items-center justify-center px-4 py-16 relative"
    >
      {/* Chapter label */}
      <motion.div
        className="mb-12 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 4.5, duration: 0.8 }}
      >
        <p className="text-[10px] uppercase tracking-[0.4em] text-neon-blue/40 font-medium">
          Chapter III
        </p>
        <h2 className="text-xl md:text-3xl font-semibold text-white mt-1">
          The Final Reveal
        </h2>
      </motion.div>

      {/* 3D Trading Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.5, y: 60 }}
        animate={confettiDone ? { opacity: 1, scale: 1, y: 0 } : { opacity: 0, scale: 0.5, y: 60 }}
        transition={{ duration: 1.2, type: 'spring', stiffness: 80 }}
      >
        <div
          ref={cardRef}
          onMouseMove={handleCardMouseMove}
          onMouseLeave={handleCardMouseLeave}
          className="relative w-[320px] md:w-[380px] rounded-2xl overflow-hidden transition-transform duration-200 ease-out cursor-pointer"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Card background */}
          <div className="relative bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-1 rounded-2xl neon-border">
            <div className="rounded-xl overflow-hidden">
              {/* Holographic shimmer */}
              <div
                className="absolute inset-0 z-10 pointer-events-none rounded-2xl"
                style={{
                  background: `radial-gradient(circle at ${shimmerX}px ${shimmerY}px, rgba(96,165,250,0.15), transparent 60%)`,
                }}
              />

              {/* Card content */}
              <div className="relative bg-gradient-to-b from-slate-950/90 via-slate-900/90 to-slate-950/90 p-6 md:p-8">
                {/* Top badge */}
                <div className="flex items-center justify-between mb-6">
                  <span className="text-[9px] uppercase tracking-[0.35em] text-neon-blue/50 font-medium">
                    Legendary Edition
                  </span>
                  <span className="px-2 py-0.5 rounded bg-neon-blue/10 text-neon-blue text-[9px] font-semibold tracking-wider">
                    LVL {AGE}
                  </span>
                </div>

                {/* Avatar */}
                <div className="w-24 h-24 md:w-28 md:h-28 mx-auto mb-6 rounded-full bg-gradient-to-br from-electric-500/30 to-neon-blue/20 border-2 border-neon-blue/20 flex items-center justify-center overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-electric-500/10 to-transparent" />
                  <img
                    src="/images/profile.jpg"
                    alt="Profile"
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>

                {/* Name */}
                <h3 className="text-center text-xl md:text-2xl font-semibold text-white mb-1">
                  {FRIEND_NAME}
                </h3>
                <p className="text-center text-[10px] uppercase tracking-[0.3em] text-neon-blue/40 mb-6">
                  Long-Distance Legend
                </p>

                {/* Stats */}
                <div className="space-y-3 mb-6">
                  {STATS.map((stat, i) => {
                    const Icon = stat.icon;
                    const isStr = typeof stat.value === 'string';
                    const pct = isStr ? 100 : Math.min(((stat.value as number) / stat.max) * 100, 100);
                    return (
                      <motion.div
                        key={stat.label}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 5 + i * 0.15, duration: 0.5 }}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <Icon className="w-3 h-3 text-neon-blue/60" />
                            <span className="text-[10px] text-white/50 uppercase tracking-wider">
                              {stat.label}
                            </span>
                          </div>
                          <span className="text-xs text-neon-blue font-medium">
                            {isStr ? stat.value : `${stat.value}/${stat.max}`}
                          </span>
                        </div>
                        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                          <motion.div
                            className="h-full rounded-full bg-gradient-to-r from-electric-500 to-neon-blue"
                            initial={{ width: 0 }}
                            animate={{ width: `${pct}%` }}
                            transition={{ delay: 5.5 + i * 0.15, duration: 1, ease: 'easeOut' }}
                          />
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Divider */}
                <div className="h-px bg-gradient-to-r from-transparent via-neon-blue/20 to-transparent mb-6" />

                {/* Birthday message */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 6.5, duration: 0.8 }}
                  className="text-center"
                >
                  <p className="text-white/70 text-xs md:text-sm leading-relaxed italic">
                    "Happy Birthday to the one who gets me like nobody else. Thank you for making my life a million times brighter and for always keeping it real with me. You're the absolute best, and I can't wait for us to absolutely crush it. Cheers to our future ventures together!"
                  </p>
                  <p className="text-neon-blue/50 text-[10px] uppercase tracking-[0.3em] mt-4">
                    LOVE YOUUUUU
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
